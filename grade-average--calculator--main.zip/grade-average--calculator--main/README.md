# grade-average--calculator-
A simple python project to calculate grade averages 
